import 'package:flutter/cupertino.dart';

BoxDecoration borderDecorationCustom(double radius, Color color) =>
    BoxDecoration(color: color, borderRadius: BorderRadius.circular(radius));
