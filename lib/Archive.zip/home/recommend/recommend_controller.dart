import 'package:myphsar/home/home_controller.dart';

class RecommendController extends HomeController {
  RecommendController(super.homeProvider);
}
