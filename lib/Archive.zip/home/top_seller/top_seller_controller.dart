import 'package:myphsar/home/home_controller.dart';

class TopSellerController extends HomeController {
  TopSellerController(super.homeProvider);
}
