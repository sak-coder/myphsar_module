
import 'package:myphsar/home/home_controller.dart';

class DailyDealController extends HomeController{
  DailyDealController(super.homeProvider);

}